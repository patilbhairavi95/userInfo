package com.spring.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.spring.Model.Users;
import com.spring.Repo.UserRepo;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;


@RestController
@CrossOrigin("*") 
public class RestApiUserC {
	@Autowired
	UserRepo repo;
	
	@GetMapping("/Users")
	public List<Users>user(){
		System.out.println(repo.findAll());
		return (List<Users>)repo.findAll();		
	}
	
	@PostMapping("/Users")
	public String addUser(@RequestBody Users users) {
		System.out.println(users);
		repo.save(users);
		return null;
		}
	
	@PutMapping("/Users")
	public  Users updateUser(@RequestBody Users users) {
		System.out.println("update user" +users);
		int i=users.getId();
		repo.findById(i).map(
				  u->{
					u.setFirstName(users.getFirstName());
					u.setLastName(users.getLastName());
					u.setMobile(users.getMobile());
					u.setEmail(users.getEmail());
					u.setAddress(users.getAddress());
					u.setAge(users.getAge());
					u.setGender(users.getGender());
					return  repo.save(users);
					
				}
				);
		
		return users;
		
	}
//	@DeleteMapping("/Users/{id}")
//	 public String deleteUser(@PathVariable("id")int id) {
//		 System.out.println("delete user by id" +id);    
//		 repo.deleteById(id);
//		 return "deleted successfully";
//		 
//	 }
	 @DeleteMapping("/Users/{id}")
	    public ResponseEntity<Map<String, String>> deleteUser(@PathVariable("id") int id) {
	        System.out.println("Deleting user with ID: " + id);
	        
	        repo.deleteById(id);  
	        
	        Map<String, String> response = new HashMap<>();
	        response.put("message", "Deleted successfully");
	        
	        return ResponseEntity.ok(response);
	    }
	 @GetMapping("/search")
	    public List<Users> searchUsers(@RequestParam String keyword) {
	        return repo.findByFirstNameContainingOrLastNameContainingOrEmailContaining(keyword, keyword, keyword);
	    }
	
}