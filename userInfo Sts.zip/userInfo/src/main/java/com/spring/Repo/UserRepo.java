package com.spring.Repo;

import java.util.Optional;

import org.apache.catalina.User;
import org.springframework.data.repository.CrudRepository;

import com.spring.Model.Users;
import java.util.List;


public interface UserRepo extends CrudRepository<Users, Integer> {
	 List<Users> findByFirstNameContainingOrLastNameContainingOrEmailContaining(String firstName, String lastName, String email);
	}